package com.example.ado1leonardobarbosa

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*


class Produto {
    var nome:String = ""
    var custo:Double = 0.0
    var venda:Double = 0.0
}

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val sh = getSharedPreferences("produto", Context.MODE_PRIVATE)
        val produto = Produto()

        btnSalvar.setOnClickListener { v: View? ->

            var nomeProduto = txtNomeProduto.text.toString()
            var precoCusto = txtPrecoCusto.text.toString()
            var precoVenda = txtPrecoVenda.text.toString()
            if (nomeProduto.isNotEmpty() && precoCusto.isNotEmpty() && precoVenda.isNotEmpty()) {

                produto.nome = txtNomeProduto.text.toString()
                produto.custo = precoCusto.toDouble()
                produto.venda = precoVenda.toDouble()

                sh.edit().putString(produto.nome, produto.custo.toString() + ";" + produto.venda.toString()).apply()
                Toast.makeText(this, "Salvo com sucesso!", Toast.LENGTH_SHORT).show()

            }

        }


        btnLimpar.setOnClickListener { v: View? ->
            txtNomeProduto.text.clear()
            txtPrecoCusto.text.clear()
            txtPrecoVenda.text.clear()
            txtProduto.text.clear()
        }

        btnCalcular.setOnClickListener { v: View? ->

            if (txtProduto.text.isNotEmpty()) {
                var texto = sh.getString(txtProduto.text.toString(), "")
                if (texto.isNullOrEmpty()) {
                    Toast.makeText(this, "Produto não encontrado!", Toast.LENGTH_SHORT).show()
            } else {
                var valorCustoVenda = texto.toString().split(";")
                txtNomeProduto.setText(txtProduto.text.toString())
                txtPrecoCusto.setText(valorCustoVenda[0])
                txtPrecoVenda.setText(valorCustoVenda[1])

                if (valorCustoVenda[0].toDouble() < valorCustoVenda[1].toDouble()) {

                    var lucro = valorCustoVenda[1].toDouble() - valorCustoVenda[0].toDouble()

                    Toast.makeText(this, "Seu lucro foi de R$ " + lucro, Toast.LENGTH_SHORT).show()
                } else {

                    var preju = valorCustoVenda[0].toDouble() - valorCustoVenda[1].toDouble()

                    Toast.makeText(this, "Seu prejuízo foi de R$ " + preju, Toast.LENGTH_SHORT).show()
                    }
                }
            } else {
                Toast.makeText(this, "Digite o nome do produto!", Toast.LENGTH_SHORT).show()
            }
        }
    }
}